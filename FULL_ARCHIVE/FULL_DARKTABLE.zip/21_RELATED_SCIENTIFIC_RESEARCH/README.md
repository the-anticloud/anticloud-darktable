# 21 Related Scientific Research

**Project:** DARKTABLE
**Upstream:** https://github.com/darktable-org/darktable

Content specific to DARKTABLE in category CAMERAS.
