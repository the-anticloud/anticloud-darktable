# 23 How To Cite

**Project:** DARKTABLE
**Upstream:** https://github.com/darktable-org/darktable

Content specific to DARKTABLE in category CAMERAS.
