# 06 Whitelabelling And Repackaging

**Project:** DARKTABLE
**Upstream:** https://github.com/darktable-org/darktable

Content specific to DARKTABLE in category CAMERAS.
