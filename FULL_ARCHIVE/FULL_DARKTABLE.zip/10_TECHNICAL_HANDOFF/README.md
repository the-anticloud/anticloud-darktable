# 10 Technical Handoff

**Project:** DARKTABLE
**Upstream:** https://github.com/darktable-org/darktable

Content specific to DARKTABLE in category CAMERAS.
