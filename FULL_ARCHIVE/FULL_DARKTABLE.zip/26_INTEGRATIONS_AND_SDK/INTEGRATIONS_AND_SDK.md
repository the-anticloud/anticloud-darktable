# Integrations and SDK — DARKTABLE

**Company:** Anticloud FZ LLE
**Model:** PAX L5 Narrow L2 General 27B
**Project:** DARKTABLE | Category: CAMERAS
**Upstream:** https://github.com/darktable-org/darktable (GPL)

## Overview

This document covers integrations and sdk for the Anticloud integration of DARKTABLE.

Professional RAW photo editor

## Anticloud Integration

PAX L5 Narrow L2 General 27B is integrated into DARKTABLE to provide:
- Local AI inference with zero cloud dependency
- AIOSS tamper-evident audit chain
- AES-256 encryption at rest
- Single-binary deployment

## Contact

Lois-Kleinner Alpasan — CEO & CTO, Anticloud FZ LLE
lois@0-1.gg | 0-1.gg
